﻿namespace Chapter_10_Exercise_10
{
    partial class PizzaMaker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblSize = new System.Windows.Forms.Label();
            this.tabsOrderBuilder = new System.Windows.Forms.TabControl();
            this.tabCustInfo = new System.Windows.Forms.TabPage();
            this.tabCustom = new System.Windows.Forms.TabPage();
            this.btnAdd2Order = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSauce = new System.Windows.Forms.Label();
            this.cboSauce = new System.Windows.Forms.ComboBox();
            this.cklToppings = new System.Windows.Forms.CheckedListBox();
            this.lblToppings = new System.Windows.Forms.Label();
            this.cboSize = new System.Windows.Forms.ComboBox();
            this.tabPizzas = new System.Windows.Forms.TabPage();
            this.rdoMed = new System.Windows.Forms.RadioButton();
            this.btnAdd = new System.Windows.Forms.Button();
            this.rdoParty = new System.Windows.Forms.RadioButton();
            this.rdoLarge = new System.Windows.Forms.RadioButton();
            this.rdoSmall = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDisclaimer = new System.Windows.Forms.Label();
            this.grpBBQ = new System.Windows.Forms.GroupBox();
            this.lblBBQ = new System.Windows.Forms.Label();
            this.chkBBQ = new System.Windows.Forms.CheckBox();
            this.chkMeatLover = new System.Windows.Forms.CheckBox();
            this.grpHawaiin = new System.Windows.Forms.GroupBox();
            this.lblHawaiinDesc = new System.Windows.Forms.Label();
            this.chkVeggie = new System.Windows.Forms.CheckBox();
            this.grpMeat = new System.Windows.Forms.GroupBox();
            this.lblMeatDesc = new System.Windows.Forms.Label();
            this.chkHawaiin = new System.Windows.Forms.CheckBox();
            this.grpVeggie = new System.Windows.Forms.GroupBox();
            this.lblVeggie = new System.Windows.Forms.Label();
            this.tabCart = new System.Windows.Forms.TabPage();
            this.lblCart = new System.Windows.Forms.Label();
            this.tabsOrderBuilder.SuspendLayout();
            this.tabCustInfo.SuspendLayout();
            this.tabCustom.SuspendLayout();
            this.tabPizzas.SuspendLayout();
            this.grpBBQ.SuspendLayout();
            this.grpHawaiin.SuspendLayout();
            this.grpMeat.SuspendLayout();
            this.grpVeggie.SuspendLayout();
            this.tabCart.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(212, 33);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(55, 24);
            this.lblName.TabIndex = 3;
            this.lblName.Text = "Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(189, 72);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 30);
            this.txtName.TabIndex = 4;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(189, 157);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(100, 30);
            this.txtPhone.TabIndex = 6;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(210, 118);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(57, 24);
            this.lblPhone.TabIndex = 5;
            this.lblPhone.Text = "Phone";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(162, 248);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(193, 30);
            this.txtAddress.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(158, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(202, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "House Number and Street";
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.Location = new System.Drawing.Point(98, 61);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(41, 24);
            this.lblSize.TabIndex = 22;
            this.lblSize.Text = "Size";
            // 
            // tabsOrderBuilder
            // 
            this.tabsOrderBuilder.Controls.Add(this.tabCustInfo);
            this.tabsOrderBuilder.Controls.Add(this.tabCustom);
            this.tabsOrderBuilder.Controls.Add(this.tabPizzas);
            this.tabsOrderBuilder.Controls.Add(this.tabCart);
            this.tabsOrderBuilder.Location = new System.Drawing.Point(75, 30);
            this.tabsOrderBuilder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabsOrderBuilder.Name = "tabsOrderBuilder";
            this.tabsOrderBuilder.SelectedIndex = 0;
            this.tabsOrderBuilder.Size = new System.Drawing.Size(512, 462);
            this.tabsOrderBuilder.TabIndex = 25;
            // 
            // tabCustInfo
            // 
            this.tabCustInfo.Controls.Add(this.txtAddress);
            this.tabCustInfo.Controls.Add(this.lblName);
            this.tabCustInfo.Controls.Add(this.txtName);
            this.tabCustInfo.Controls.Add(this.label3);
            this.tabCustInfo.Controls.Add(this.lblPhone);
            this.tabCustInfo.Controls.Add(this.txtPhone);
            this.tabCustInfo.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCustInfo.Location = new System.Drawing.Point(4, 25);
            this.tabCustInfo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabCustInfo.Name = "tabCustInfo";
            this.tabCustInfo.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabCustInfo.Size = new System.Drawing.Size(504, 433);
            this.tabCustInfo.TabIndex = 0;
            this.tabCustInfo.Text = "Ordering Info";
            this.tabCustInfo.UseVisualStyleBackColor = true;
            // 
            // tabCustom
            // 
            this.tabCustom.Controls.Add(this.btnAdd2Order);
            this.tabCustom.Controls.Add(this.label4);
            this.tabCustom.Controls.Add(this.lblSauce);
            this.tabCustom.Controls.Add(this.cboSauce);
            this.tabCustom.Controls.Add(this.cklToppings);
            this.tabCustom.Controls.Add(this.lblToppings);
            this.tabCustom.Controls.Add(this.cboSize);
            this.tabCustom.Controls.Add(this.lblSize);
            this.tabCustom.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCustom.Location = new System.Drawing.Point(4, 25);
            this.tabCustom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabCustom.Name = "tabCustom";
            this.tabCustom.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabCustom.Size = new System.Drawing.Size(504, 433);
            this.tabCustom.TabIndex = 1;
            this.tabCustom.Text = "Pizza Builder";
            this.tabCustom.UseVisualStyleBackColor = true;
            // 
            // btnAdd2Order
            // 
            this.btnAdd2Order.Location = new System.Drawing.Point(174, 293);
            this.btnAdd2Order.Name = "btnAdd2Order";
            this.btnAdd2Order.Size = new System.Drawing.Size(109, 62);
            this.btnAdd2Order.TabIndex = 37;
            this.btnAdd2Order.Text = "Add To Order";
            this.btnAdd2Order.UseVisualStyleBackColor = true;
            this.btnAdd2Order.Click += new System.EventHandler(this.btnAdd2Order_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(366, 24);
            this.label4.TabIndex = 36;
            this.label4.Text = "Default is a medium tomato sauce, cheese pizza";
            // 
            // lblSauce
            // 
            this.lblSauce.AutoSize = true;
            this.lblSauce.Location = new System.Drawing.Point(98, 163);
            this.lblSauce.Name = "lblSauce";
            this.lblSauce.Size = new System.Drawing.Size(56, 24);
            this.lblSauce.TabIndex = 35;
            this.lblSauce.Text = "Sauce";
            // 
            // cboSauce
            // 
            this.cboSauce.FormattingEnabled = true;
            this.cboSauce.Items.AddRange(new object[] {
            "Tomato ($0.50)",
            "Alfredo($0.75)",
            "BBQ ($1.00)"});
            this.cboSauce.Location = new System.Drawing.Point(61, 205);
            this.cboSauce.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboSauce.Name = "cboSauce";
            this.cboSauce.Size = new System.Drawing.Size(143, 32);
            this.cboSauce.TabIndex = 34;
            // 
            // cklToppings
            // 
            this.cklToppings.CheckOnClick = true;
            this.cklToppings.FormattingEnabled = true;
            this.cklToppings.Items.AddRange(new object[] {
            "Pepperoni",
            "Sausage",
            "Bacon",
            "Ham Chunks",
            "Bell Peppers",
            "Banana Peppers",
            "Jalepenos",
            "Onions",
            "Mushrooms",
            "Black Olives",
            "Pinapples",
            "Chicken Chunks",
            "Spinach",
            "Extra Cheese"});
            this.cklToppings.Location = new System.Drawing.Point(255, 85);
            this.cklToppings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cklToppings.Name = "cklToppings";
            this.cklToppings.Size = new System.Drawing.Size(195, 179);
            this.cklToppings.TabIndex = 33;
            // 
            // lblToppings
            // 
            this.lblToppings.AutoSize = true;
            this.lblToppings.Location = new System.Drawing.Point(263, 48);
            this.lblToppings.Name = "lblToppings";
            this.lblToppings.Size = new System.Drawing.Size(174, 24);
            this.lblToppings.TabIndex = 23;
            this.lblToppings.Text = "Toppings ($1.50 Each)";
            // 
            // cboSize
            // 
            this.cboSize.FormattingEnabled = true;
            this.cboSize.Items.AddRange(new object[] {
            "Small ($2.49 10in.)",
            "Medium ($4.49 12in.)",
            "Large ($6.49 14in.)",
            "Party (8.49 16in.)"});
            this.cboSize.Location = new System.Drawing.Point(28, 97);
            this.cboSize.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboSize.Name = "cboSize";
            this.cboSize.Size = new System.Drawing.Size(199, 32);
            this.cboSize.TabIndex = 24;
            // 
            // tabPizzas
            // 
            this.tabPizzas.Controls.Add(this.rdoMed);
            this.tabPizzas.Controls.Add(this.btnAdd);
            this.tabPizzas.Controls.Add(this.rdoParty);
            this.tabPizzas.Controls.Add(this.rdoLarge);
            this.tabPizzas.Controls.Add(this.rdoSmall);
            this.tabPizzas.Controls.Add(this.label1);
            this.tabPizzas.Controls.Add(this.lblDisclaimer);
            this.tabPizzas.Controls.Add(this.grpBBQ);
            this.tabPizzas.Controls.Add(this.chkBBQ);
            this.tabPizzas.Controls.Add(this.chkMeatLover);
            this.tabPizzas.Controls.Add(this.grpHawaiin);
            this.tabPizzas.Controls.Add(this.chkVeggie);
            this.tabPizzas.Controls.Add(this.grpMeat);
            this.tabPizzas.Controls.Add(this.chkHawaiin);
            this.tabPizzas.Controls.Add(this.grpVeggie);
            this.tabPizzas.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPizzas.Location = new System.Drawing.Point(4, 25);
            this.tabPizzas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPizzas.Name = "tabPizzas";
            this.tabPizzas.Size = new System.Drawing.Size(504, 433);
            this.tabPizzas.TabIndex = 2;
            this.tabPizzas.Text = "Deals";
            this.tabPizzas.UseVisualStyleBackColor = true;
            // 
            // rdoMed
            // 
            this.rdoMed.AutoSize = true;
            this.rdoMed.Checked = true;
            this.rdoMed.Location = new System.Drawing.Point(123, 333);
            this.rdoMed.Name = "rdoMed";
            this.rdoMed.Size = new System.Drawing.Size(91, 28);
            this.rdoMed.TabIndex = 39;
            this.rdoMed.TabStop = true;
            this.rdoMed.Tag = "rdoSize";
            this.rdoMed.Text = "Medium";
            this.rdoMed.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(183, 367);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(109, 62);
            this.btnAdd.TabIndex = 38;
            this.btnAdd.Text = "Add To Order";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // rdoParty
            // 
            this.rdoParty.AutoSize = true;
            this.rdoParty.Location = new System.Drawing.Point(380, 333);
            this.rdoParty.Name = "rdoParty";
            this.rdoParty.Size = new System.Drawing.Size(108, 28);
            this.rdoParty.TabIndex = 16;
            this.rdoParty.Tag = "rdoSize";
            this.rdoParty.Text = "P (+$2.00)";
            this.rdoParty.UseVisualStyleBackColor = true;
            // 
            // rdoLarge
            // 
            this.rdoLarge.AutoSize = true;
            this.rdoLarge.Location = new System.Drawing.Point(243, 333);
            this.rdoLarge.Name = "rdoLarge";
            this.rdoLarge.Size = new System.Drawing.Size(106, 28);
            this.rdoLarge.TabIndex = 15;
            this.rdoLarge.Tag = "rdoSize";
            this.rdoLarge.Text = "L (+$1.00)";
            this.rdoLarge.UseVisualStyleBackColor = true;
            // 
            // rdoSmall
            // 
            this.rdoSmall.AutoSize = true;
            this.rdoSmall.Location = new System.Drawing.Point(3, 333);
            this.rdoSmall.Name = "rdoSmall";
            this.rdoSmall.Size = new System.Drawing.Size(103, 28);
            this.rdoSmall.TabIndex = 9;
            this.rdoSmall.Tag = "rdoSize";
            this.rdoSmall.Text = "S (-$1.00)";
            this.rdoSmall.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(411, 48);
            this.label1.TabIndex = 13;
            this.label1.Text = "Medium is shown pricing, S=Small (will be less to pay),\r\nL=Large, P=Party\r\n";
            // 
            // lblDisclaimer
            // 
            this.lblDisclaimer.AutoSize = true;
            this.lblDisclaimer.Location = new System.Drawing.Point(76, 5);
            this.lblDisclaimer.Name = "lblDisclaimer";
            this.lblDisclaimer.Size = new System.Drawing.Size(311, 24);
            this.lblDisclaimer.TabIndex = 12;
            this.lblDisclaimer.Text = "Modifying will be at normal custom prices";
            // 
            // grpBBQ
            // 
            this.grpBBQ.Controls.Add(this.lblBBQ);
            this.grpBBQ.Location = new System.Drawing.Point(255, 227);
            this.grpBBQ.Name = "grpBBQ";
            this.grpBBQ.Size = new System.Drawing.Size(233, 100);
            this.grpBBQ.TabIndex = 0;
            this.grpBBQ.TabStop = false;
            // 
            // lblBBQ
            // 
            this.lblBBQ.AutoSize = true;
            this.lblBBQ.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lblBBQ.Location = new System.Drawing.Point(6, 20);
            this.lblBBQ.Name = "lblBBQ";
            this.lblBBQ.Size = new System.Drawing.Size(198, 66);
            this.lblBBQ.TabIndex = 9;
            this.lblBBQ.Text = "BBQ suace, Ham, Chunks, \r\nSausage, Bell  Peppers,\r\nMushrooms, Chicken Chunks";
            // 
            // chkBBQ
            // 
            this.chkBBQ.AutoSize = true;
            this.chkBBQ.Location = new System.Drawing.Point(254, 204);
            this.chkBBQ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkBBQ.Name = "chkBBQ";
            this.chkBBQ.Size = new System.Drawing.Size(132, 28);
            this.chkBBQ.TabIndex = 3;
            this.chkBBQ.Text = "BBQ ($12.50)";
            this.chkBBQ.UseVisualStyleBackColor = true;
            // 
            // chkMeatLover
            // 
            this.chkMeatLover.AutoSize = true;
            this.chkMeatLover.Location = new System.Drawing.Point(15, 204);
            this.chkMeatLover.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkMeatLover.Name = "chkMeatLover";
            this.chkMeatLover.Size = new System.Drawing.Size(189, 28);
            this.chkMeatLover.TabIndex = 2;
            this.chkMeatLover.Text = "Meat Lovers ($10.00)";
            this.chkMeatLover.UseVisualStyleBackColor = true;
            // 
            // grpHawaiin
            // 
            this.grpHawaiin.Controls.Add(this.lblHawaiinDesc);
            this.grpHawaiin.Location = new System.Drawing.Point(15, 102);
            this.grpHawaiin.Name = "grpHawaiin";
            this.grpHawaiin.Size = new System.Drawing.Size(227, 97);
            this.grpHawaiin.TabIndex = 10;
            this.grpHawaiin.TabStop = false;
            // 
            // lblHawaiinDesc
            // 
            this.lblHawaiinDesc.AutoSize = true;
            this.lblHawaiinDesc.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHawaiinDesc.Location = new System.Drawing.Point(6, 24);
            this.lblHawaiinDesc.Name = "lblHawaiinDesc";
            this.lblHawaiinDesc.Size = new System.Drawing.Size(196, 66);
            this.lblHawaiinDesc.TabIndex = 6;
            this.lblHawaiinDesc.Text = "BBQ sauce, Chicken Chunks,\r\nPineapple, Bacon, Banana\r\nPeppers";
            // 
            // chkVeggie
            // 
            this.chkVeggie.AutoSize = true;
            this.chkVeggie.Location = new System.Drawing.Point(254, 79);
            this.chkVeggie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkVeggie.Name = "chkVeggie";
            this.chkVeggie.Size = new System.Drawing.Size(175, 28);
            this.chkVeggie.TabIndex = 1;
            this.chkVeggie.Text = "Vegetarian ($11.75)";
            this.chkVeggie.UseVisualStyleBackColor = true;
            // 
            // grpMeat
            // 
            this.grpMeat.Controls.Add(this.lblMeatDesc);
            this.grpMeat.Location = new System.Drawing.Point(15, 227);
            this.grpMeat.Name = "grpMeat";
            this.grpMeat.Size = new System.Drawing.Size(233, 95);
            this.grpMeat.TabIndex = 11;
            this.grpMeat.TabStop = false;
            // 
            // lblMeatDesc
            // 
            this.lblMeatDesc.AutoSize = true;
            this.lblMeatDesc.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lblMeatDesc.Location = new System.Drawing.Point(6, 20);
            this.lblMeatDesc.Name = "lblMeatDesc";
            this.lblMeatDesc.Size = new System.Drawing.Size(205, 44);
            this.lblMeatDesc.TabIndex = 7;
            this.lblMeatDesc.Text = "Tomato sauce, Pepperoni,\r\nSausage, Bacon, Ham Chunks";
            // 
            // chkHawaiin
            // 
            this.chkHawaiin.AutoSize = true;
            this.chkHawaiin.Location = new System.Drawing.Point(15, 79);
            this.chkHawaiin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkHawaiin.Name = "chkHawaiin";
            this.chkHawaiin.Size = new System.Drawing.Size(155, 28);
            this.chkHawaiin.TabIndex = 0;
            this.chkHawaiin.Text = "Hawaiin ($11.99)";
            this.chkHawaiin.UseVisualStyleBackColor = true;
            // 
            // grpVeggie
            // 
            this.grpVeggie.Controls.Add(this.lblVeggie);
            this.grpVeggie.Location = new System.Drawing.Point(255, 102);
            this.grpVeggie.Name = "grpVeggie";
            this.grpVeggie.Size = new System.Drawing.Size(246, 100);
            this.grpVeggie.TabIndex = 0;
            this.grpVeggie.TabStop = false;
            // 
            // lblVeggie
            // 
            this.lblVeggie.AutoSize = true;
            this.lblVeggie.Font = new System.Drawing.Font("Arial Narrow", 10F);
            this.lblVeggie.Location = new System.Drawing.Point(6, 21);
            this.lblVeggie.Name = "lblVeggie";
            this.lblVeggie.Size = new System.Drawing.Size(188, 66);
            this.lblVeggie.TabIndex = 8;
            this.lblVeggie.Text = "Alfredo sauce, Bell Peppers,\r\nBanana Peppers, Onions, \r\nMushrooms, Black Olives ";
            // 
            // tabCart
            // 
            this.tabCart.Controls.Add(this.lblCart);
            this.tabCart.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCart.Location = new System.Drawing.Point(4, 25);
            this.tabCart.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabCart.Name = "tabCart";
            this.tabCart.Size = new System.Drawing.Size(504, 433);
            this.tabCart.TabIndex = 4;
            this.tabCart.Text = "Cart";
            this.tabCart.UseVisualStyleBackColor = true;
            // 
            // lblCart
            // 
            this.lblCart.AutoSize = true;
            this.lblCart.Location = new System.Drawing.Point(33, 25);
            this.lblCart.MaximumSize = new System.Drawing.Size(430, 300);
            this.lblCart.MinimumSize = new System.Drawing.Size(430, 0);
            this.lblCart.Name = "lblCart";
            this.lblCart.Size = new System.Drawing.Size(430, 24);
            this.lblCart.TabIndex = 0;
            this.lblCart.Text = " ";
            // 
            // PizzaMaker
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 550);
            this.Controls.Add(this.tabsOrderBuilder);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "PizzaMaker";
            this.Text = "Pizza Ordering";
            this.tabsOrderBuilder.ResumeLayout(false);
            this.tabCustInfo.ResumeLayout(false);
            this.tabCustInfo.PerformLayout();
            this.tabCustom.ResumeLayout(false);
            this.tabCustom.PerformLayout();
            this.tabPizzas.ResumeLayout(false);
            this.tabPizzas.PerformLayout();
            this.grpBBQ.ResumeLayout(false);
            this.grpBBQ.PerformLayout();
            this.grpHawaiin.ResumeLayout(false);
            this.grpHawaiin.PerformLayout();
            this.grpMeat.ResumeLayout(false);
            this.grpMeat.PerformLayout();
            this.grpVeggie.ResumeLayout(false);
            this.grpVeggie.PerformLayout();
            this.tabCart.ResumeLayout(false);
            this.tabCart.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblSize;
        private System.Windows.Forms.TabControl tabsOrderBuilder;
        private System.Windows.Forms.TabPage tabCustInfo;
        private System.Windows.Forms.TabPage tabCustom;
        private System.Windows.Forms.TabPage tabPizzas;
        private System.Windows.Forms.Label lblToppings;
        private System.Windows.Forms.ComboBox cboSize;
        private System.Windows.Forms.CheckedListBox cklToppings;
        private System.Windows.Forms.TabPage tabCart;
        private System.Windows.Forms.ComboBox cboSauce;
        private System.Windows.Forms.Label lblSauce;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkBBQ;
        private System.Windows.Forms.CheckBox chkMeatLover;
        private System.Windows.Forms.CheckBox chkVeggie;
        private System.Windows.Forms.CheckBox chkHawaiin;
        private System.Windows.Forms.Label lblBBQ;
        private System.Windows.Forms.Label lblVeggie;
        private System.Windows.Forms.Label lblMeatDesc;
        private System.Windows.Forms.Label lblHawaiinDesc;
        private System.Windows.Forms.GroupBox grpHawaiin;
        private System.Windows.Forms.GroupBox grpMeat;
        private System.Windows.Forms.GroupBox grpBBQ;
        private System.Windows.Forms.GroupBox grpVeggie;
        private System.Windows.Forms.Button btnAdd2Order;
        private System.Windows.Forms.Label lblDisclaimer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdoSmall;
        private System.Windows.Forms.RadioButton rdoLarge;
        private System.Windows.Forms.RadioButton rdoParty;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.RadioButton rdoMed;
        private System.Windows.Forms.Label lblCart;
    }
}

