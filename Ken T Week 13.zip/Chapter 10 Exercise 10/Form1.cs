﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter_10_Exercise_10
{
    public partial class PizzaMaker : Form
    {
        public PizzaMaker()
        {
            InitializeComponent();
            
        }

        //could do with a jagged array but i don't feel like it's worth it for just three items and
        //two of them being a single item but the jagged array might be better for mor complex cases
        private void btnAdd2Order_Click(object sender, EventArgs e)
        {
            double price;
            price = 0;
            switch (cboSize.SelectedIndex)
            {
                case 0:
                    price = 8.99; break;
                case 1:
                    price = 10.99; break;
                case 2:
                    price = 12.99; break;
                default:
                    price = 10.99; break;
            }
            switch (cboSauce.SelectedIndex) 
            {
                case 0:
                    price += 0.50; break;
                case 1:
                    price += 0.75; break;
                case 2:
                    price += 1; break;
                default:
                    price += 0.50; break;
            }

            price += (1.5 * cklToppings.CheckedItems.Count);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            double price = 0;
            if (chkHawaiin.Checked)
                price = 11.99;
            else if (chkVeggie.Checked)
                price = 11.75;
            else if (chkMeatLover.Checked)
                price = 10.00;
            else if (chkVeggie.Checked)
                price = 12.50;
            if (rdoSmall.Checked) 
                price -= 1.00;
            else if(rdoMed.Checked)
                price += 0.00;
            else if (rdoLarge.Checked)
                price += 1.00;
            else if (rdoParty.Checked)
                price += 2.00;

        }
        
    }
}
