﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C9PE10
{
    public partial class Form1 : Form
    {
        GameData GD = new GameData();
        Random random = new Random();
        public Form1()
        {
            InitializeComponent();
            GD.Target = random.Next(0, 101);
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtGuess.Text) || !int.TryParse(txtGuess.Text, out int guess)) 
            {
                MessageBox.Show("Invalid Guess");
                txtGuess.Text = "";
            }
            else 
            {
                GD.Guess = guess;
                GD.TotalGuesses += 1;
                lblGuesses.Text = "Guesses: " + GD.TotalGuesses;
                if (GD.Guess == GD.Target) 
                {
                    BackColor = Color.Green;
                }
                if (GD.Guess < GD.Target) 
                {
                    BackColor = Color.SaddleBrown;
                }
                if (GD.Guess > GD.Target) 
                {
                    BackColor = Color.SkyBlue;
                }
            } 
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            GD.TotalGuesses = 0;
            txtGuess.Text = "";
            lblGuesses.Text = "Guesses: 0";
            GD.Target = random.Next(0, 101);
            BackColor = Color.WhiteSmoke;
        }
    }
}
