﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C9PE10
{
    internal class GameData
    {
        public int Target {  get; set; }
        public int Guess { get; set; }
        public int TotalGuesses { get; set; }

    }
    
}
