﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C9PE10
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            /*
             * Create the higher/lower guessing game using a GUI. 
             * Allow users to keep guessing until they guess the number. 
             * Keep a count of the number of guesses. Choose two colors for your game: 
             * one should be used to indicate that the value the users guessed is higher than the target; 
             * the other is used to indicate that the value the users guessed is lower than the target. 
             * With each new guess, show the guess count and change the form color based on whether the guess is higher than the target or lower. 
             * When they hit the target, display a message on a label indicating the number of guesses it took. 
             * Provide a reset button to enable the user to re-start the game without re-running your application. 
             * Tie the guess button to the enter key and the reset button to the cancel key. 
             * Several approaches can be used to seed the target: One is to generate a random number by constructing an object of the Random class. 
             * For example, the following stores a random whole number between 0 and 100 in target: 
             * Random r = new Random( );
             * int target = r.Next(0,101);
             */
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
            
        }
    }
}
