﻿namespace Week13_Group
{
    partial class Checkout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLbl = new System.Windows.Forms.Label();
            this.addressLbl = new System.Windows.Forms.Label();
            this.phoneLbl = new System.Windows.Forms.Label();
            this.emailLbl = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.textAddress = new System.Windows.Forms.TextBox();
            this.textPhone = new System.Windows.Forms.TextBox();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.orderInfoLbl = new System.Windows.Forms.Label();
            this.pizzaSizeLbl = new System.Windows.Forms.Label();
            this.pizzaSizeSelectionLbl = new System.Windows.Forms.Label();
            this.beverageLbl = new System.Windows.Forms.Label();
            this.bevSelectedLbl = new System.Windows.Forms.Label();
            this.costLbl = new System.Windows.Forms.Label();
            this.costSelectLbl = new System.Windows.Forms.Label();
            this.resetBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(56, 82);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(60, 20);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Name:";
            // 
            // addressLbl
            // 
            this.addressLbl.AutoSize = true;
            this.addressLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressLbl.Location = new System.Drawing.Point(56, 120);
            this.addressLbl.Name = "addressLbl";
            this.addressLbl.Size = new System.Drawing.Size(80, 20);
            this.addressLbl.TabIndex = 1;
            this.addressLbl.Text = "Address:";
            // 
            // phoneLbl
            // 
            this.phoneLbl.AutoSize = true;
            this.phoneLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneLbl.Location = new System.Drawing.Point(56, 158);
            this.phoneLbl.Name = "phoneLbl";
            this.phoneLbl.Size = new System.Drawing.Size(65, 20);
            this.phoneLbl.TabIndex = 2;
            this.phoneLbl.Text = "Phone:";
            // 
            // emailLbl
            // 
            this.emailLbl.AutoSize = true;
            this.emailLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailLbl.Location = new System.Drawing.Point(56, 197);
            this.emailLbl.Name = "emailLbl";
            this.emailLbl.Size = new System.Drawing.Size(58, 20);
            this.emailLbl.TabIndex = 3;
            this.emailLbl.Text = "Email:";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(142, 84);
            this.textName.Name = "textName";
            this.textName.ReadOnly = true;
            this.textName.Size = new System.Drawing.Size(100, 20);
            this.textName.TabIndex = 4;
            // 
            // textAddress
            // 
            this.textAddress.Location = new System.Drawing.Point(142, 122);
            this.textAddress.Name = "textAddress";
            this.textAddress.ReadOnly = true;
            this.textAddress.Size = new System.Drawing.Size(100, 20);
            this.textAddress.TabIndex = 5;
            // 
            // textPhone
            // 
            this.textPhone.Location = new System.Drawing.Point(142, 160);
            this.textPhone.Name = "textPhone";
            this.textPhone.ReadOnly = true;
            this.textPhone.Size = new System.Drawing.Size(100, 20);
            this.textPhone.TabIndex = 6;
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(142, 199);
            this.textEmail.Name = "textEmail";
            this.textEmail.ReadOnly = true;
            this.textEmail.Size = new System.Drawing.Size(100, 20);
            this.textEmail.TabIndex = 7;
            // 
            // orderInfoLbl
            // 
            this.orderInfoLbl.AutoSize = true;
            this.orderInfoLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderInfoLbl.Location = new System.Drawing.Point(66, 21);
            this.orderInfoLbl.Name = "orderInfoLbl";
            this.orderInfoLbl.Size = new System.Drawing.Size(205, 31);
            this.orderInfoLbl.TabIndex = 8;
            this.orderInfoLbl.Text = "Order Summary";
            // 
            // pizzaSizeLbl
            // 
            this.pizzaSizeLbl.AutoSize = true;
            this.pizzaSizeLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pizzaSizeLbl.Location = new System.Drawing.Point(56, 246);
            this.pizzaSizeLbl.Name = "pizzaSizeLbl";
            this.pizzaSizeLbl.Size = new System.Drawing.Size(97, 20);
            this.pizzaSizeLbl.TabIndex = 9;
            this.pizzaSizeLbl.Text = "Pizza Size:";
            // 
            // pizzaSizeSelectionLbl
            // 
            this.pizzaSizeSelectionLbl.AutoSize = true;
            this.pizzaSizeSelectionLbl.Location = new System.Drawing.Point(179, 251);
            this.pizzaSizeSelectionLbl.Name = "pizzaSizeSelectionLbl";
            this.pizzaSizeSelectionLbl.Size = new System.Drawing.Size(13, 13);
            this.pizzaSizeSelectionLbl.TabIndex = 10;
            this.pizzaSizeSelectionLbl.Text = "?";
            // 
            // beverageLbl
            // 
            this.beverageLbl.AutoSize = true;
            this.beverageLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.beverageLbl.Location = new System.Drawing.Point(56, 280);
            this.beverageLbl.Name = "beverageLbl";
            this.beverageLbl.Size = new System.Drawing.Size(90, 20);
            this.beverageLbl.TabIndex = 11;
            this.beverageLbl.Text = "Beverage:";
            // 
            // bevSelectedLbl
            // 
            this.bevSelectedLbl.AutoSize = true;
            this.bevSelectedLbl.Location = new System.Drawing.Point(179, 285);
            this.bevSelectedLbl.Name = "bevSelectedLbl";
            this.bevSelectedLbl.Size = new System.Drawing.Size(13, 13);
            this.bevSelectedLbl.TabIndex = 12;
            this.bevSelectedLbl.Text = "?";
            // 
            // costLbl
            // 
            this.costLbl.AutoSize = true;
            this.costLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costLbl.Location = new System.Drawing.Point(56, 311);
            this.costLbl.Name = "costLbl";
            this.costLbl.Size = new System.Drawing.Size(51, 20);
            this.costLbl.TabIndex = 13;
            this.costLbl.Text = "Cost:";
            // 
            // costSelectLbl
            // 
            this.costSelectLbl.AutoSize = true;
            this.costSelectLbl.Location = new System.Drawing.Point(179, 316);
            this.costSelectLbl.Name = "costSelectLbl";
            this.costSelectLbl.Size = new System.Drawing.Size(13, 13);
            this.costSelectLbl.TabIndex = 14;
            this.costSelectLbl.Text = "?";
            // 
            // resetBtn
            // 
            this.resetBtn.Location = new System.Drawing.Point(127, 366);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(75, 23);
            this.resetBtn.TabIndex = 15;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(170, 316);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "$";
            // 
            // Checkout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 417);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.costSelectLbl);
            this.Controls.Add(this.costLbl);
            this.Controls.Add(this.bevSelectedLbl);
            this.Controls.Add(this.beverageLbl);
            this.Controls.Add(this.pizzaSizeSelectionLbl);
            this.Controls.Add(this.pizzaSizeLbl);
            this.Controls.Add(this.orderInfoLbl);
            this.Controls.Add(this.textEmail);
            this.Controls.Add(this.textPhone);
            this.Controls.Add(this.textAddress);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.emailLbl);
            this.Controls.Add(this.phoneLbl);
            this.Controls.Add(this.addressLbl);
            this.Controls.Add(this.nameLbl);
            this.Name = "Checkout";
            this.Text = "Order Summary";
            this.Load += new System.EventHandler(this.checkoutForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label addressLbl;
        private System.Windows.Forms.Label phoneLbl;
        private System.Windows.Forms.Label emailLbl;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textAddress;
        private System.Windows.Forms.TextBox textPhone;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.Label orderInfoLbl;
        private System.Windows.Forms.Label pizzaSizeLbl;
        private System.Windows.Forms.Label pizzaSizeSelectionLbl;
        private System.Windows.Forms.Label beverageLbl;
        private System.Windows.Forms.Label bevSelectedLbl;
        private System.Windows.Forms.Label costLbl;
        private System.Windows.Forms.Label costSelectLbl;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Label label1;
    }
}