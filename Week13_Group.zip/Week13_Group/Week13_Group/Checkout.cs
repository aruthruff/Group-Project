﻿/* 
* Programmer: Anthony Ruthruff
*             Richard Carson
*             (Kenneth Thompson)
*             (Nathaniel Gebers)
*             (Last two names added in good-faith, both members usually contribute before midnite on due date)
* Date: 05/02/2024
* Class: CITP 180
* Purpose:   Pizza Delivery App. User is initially prompted to enter contact information.
*            User is then able to choose pizza size/quantity, toppings, type of beverage/quantity
*            and extra items such as meat/veggie lovers pizza, chicken strips, and bread/cheese sticks.
*            Price of items are tallied until order is placed. Total cost will then be displayed
*            in separate window, along with contact info, pizza size, and type of beverage.
*            User can reset order at any time from order window or order summary window.
* Assignment: Chapter 10 - Programming Excercise 10
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week13_Group
{
    public partial class Checkout : Form
    {
        public Checkout()
        {
            InitializeComponent();
        }

        private void checkoutForm_Load(object sender, EventArgs e)
        {
            textName.Text = Form1.name;
            textAddress.Text = Form1.address;
            textPhone.Text = Form1.phone.ToString();
            textEmail.Text = Form1.email;
            pizzaSizeSelectionLbl.Text = Form1.pizzaSize;
            bevSelectedLbl.Text = Form1.beverage;
            costSelectLbl.Text = Form1.totalCost.ToString();

        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            textName.Text = " ";
            textAddress.Text = " ";
            textPhone.Text = " ";
            textEmail.Text = " ";
            costSelectLbl.Text = null;
            Form1.bevQty = 0;
            Form1.extraCost = 0;
        }
    }
}



