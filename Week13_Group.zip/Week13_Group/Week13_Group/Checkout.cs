﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week13_Group
{
    public partial class Checkout : Form
    {
        public Checkout()
        {
            InitializeComponent();
        }

        private void checkoutForm_Load(object sender, EventArgs e)
        {
            textName.Text = Form1.name;
            textAddress.Text = Form1.address;
            textPhone.Text = Form1.phone.ToString();
            textEmail.Text = Form1.email;
            pizzaSizeSelectionLbl.Text = Form1.pizzaSize;
            bevSelectedLbl.Text = Form1.beverage;
            costSelectLbl.Text = Form1.totalCost.ToString();
        }



        private void resetBtn_Click(object sender, EventArgs e)
        {
            textName.Text = " ";
            textAddress.Text = " ";
            textPhone.Text = " ";
            textEmail.Text = " ";
            costSelectLbl.Text = null;
            Form1.bevQty = 0;
        }
    }
}

