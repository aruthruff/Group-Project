﻿namespace Week13_Group
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.companyLbl = new System.Windows.Forms.Label();
            this.nameLbl = new System.Windows.Forms.Label();
            this.addressLbl = new System.Windows.Forms.Label();
            this.phoneLbl = new System.Windows.Forms.Label();
            this.emailLbl = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.textAddress = new System.Windows.Forms.TextBox();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.textPhone = new System.Windows.Forms.TextBox();
            this.orderBtn = new System.Windows.Forms.Button();
            this.pizzaSizeCmboBx = new System.Windows.Forms.ComboBox();
            this.pizzaSizeLbl = new System.Windows.Forms.Label();
            this.mainTab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textPizzaQty = new System.Windows.Forms.TextBox();
            this.pizzaQtyLbl = new System.Windows.Forms.Label();
            this.toppingPriceLbl = new System.Windows.Forms.Label();
            this.clearToppingBtn = new System.Windows.Forms.Button();
            this.addToppingBtn = new System.Windows.Forms.Button();
            this.toppingListAdd = new System.Windows.Forms.ListBox();
            this.toppingList = new System.Windows.Forms.CheckedListBox();
            this.toppingInfoLbl = new System.Windows.Forms.Label();
            this.sizeSelectedLbl = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.drinkLbl = new System.Windows.Forms.Label();
            this.bevInfoLbl = new System.Windows.Forms.Label();
            this.bevQntyLbl = new System.Windows.Forms.Label();
            this.textBevQty = new System.Windows.Forms.TextBox();
            this.beverageSelectedLbl = new System.Windows.Forms.Label();
            this.beverageLbl = new System.Windows.Forms.Label();
            this.beverageCmboBx = new System.Windows.Forms.ComboBox();
            this.resetBtn = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.extrasLbl = new System.Windows.Forms.Label();
            this.addChicken = new System.Windows.Forms.CheckBox();
            this.addBread = new System.Windows.Forms.CheckBox();
            this.addCheeseBread = new System.Windows.Forms.CheckBox();
            this.addMeatLover = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.addVeggie = new System.Windows.Forms.CheckBox();
            this.mainTab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // companyLbl
            // 
            this.companyLbl.AutoSize = true;
            this.companyLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companyLbl.Location = new System.Drawing.Point(26, 10);
            this.companyLbl.Name = "companyLbl";
            this.companyLbl.Size = new System.Drawing.Size(217, 31);
            this.companyLbl.TabIndex = 0;
            this.companyLbl.Text = "Pizza Company";
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(48, 191);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(49, 17);
            this.nameLbl.TabIndex = 1;
            this.nameLbl.Text = "Name:";
            // 
            // addressLbl
            // 
            this.addressLbl.AutoSize = true;
            this.addressLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressLbl.Location = new System.Drawing.Point(48, 230);
            this.addressLbl.Name = "addressLbl";
            this.addressLbl.Size = new System.Drawing.Size(64, 17);
            this.addressLbl.TabIndex = 2;
            this.addressLbl.Text = "Address:";
            // 
            // phoneLbl
            // 
            this.phoneLbl.AutoSize = true;
            this.phoneLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneLbl.Location = new System.Drawing.Point(50, 315);
            this.phoneLbl.Name = "phoneLbl";
            this.phoneLbl.Size = new System.Drawing.Size(53, 17);
            this.phoneLbl.TabIndex = 3;
            this.phoneLbl.Text = "Phone:";
            // 
            // emailLbl
            // 
            this.emailLbl.AutoSize = true;
            this.emailLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailLbl.Location = new System.Drawing.Point(50, 274);
            this.emailLbl.Name = "emailLbl";
            this.emailLbl.Size = new System.Drawing.Size(51, 17);
            this.emailLbl.TabIndex = 4;
            this.emailLbl.Text = "E-mail:";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(121, 191);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(100, 20);
            this.textName.TabIndex = 5;
            this.textName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textName_KeyDown);
            // 
            // textAddress
            // 
            this.textAddress.Location = new System.Drawing.Point(121, 230);
            this.textAddress.Name = "textAddress";
            this.textAddress.Size = new System.Drawing.Size(100, 20);
            this.textAddress.TabIndex = 6;
            this.textAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textAddress_KeyDown);
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(121, 274);
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(100, 20);
            this.textEmail.TabIndex = 7;
            this.textEmail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textEmail_KeyDown);
            // 
            // textPhone
            // 
            this.textPhone.Location = new System.Drawing.Point(121, 315);
            this.textPhone.Name = "textPhone";
            this.textPhone.Size = new System.Drawing.Size(100, 20);
            this.textPhone.TabIndex = 8;
            this.textPhone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textPhone_KeyDown);
            // 
            // orderBtn
            // 
            this.orderBtn.Location = new System.Drawing.Point(40, 421);
            this.orderBtn.Name = "orderBtn";
            this.orderBtn.Size = new System.Drawing.Size(75, 23);
            this.orderBtn.TabIndex = 9;
            this.orderBtn.Text = "Order";
            this.orderBtn.UseVisualStyleBackColor = true;
            this.orderBtn.Click += new System.EventHandler(this.orderBtn_Click);
            // 
            // pizzaSizeCmboBx
            // 
            this.pizzaSizeCmboBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.pizzaSizeCmboBx.FormattingEnabled = true;
            this.pizzaSizeCmboBx.Items.AddRange(new object[] {
            "Small",
            "Medium",
            "Large"});
            this.pizzaSizeCmboBx.Location = new System.Drawing.Point(114, 63);
            this.pizzaSizeCmboBx.Name = "pizzaSizeCmboBx";
            this.pizzaSizeCmboBx.Size = new System.Drawing.Size(121, 21);
            this.pizzaSizeCmboBx.TabIndex = 10;
            this.pizzaSizeCmboBx.SelectedIndexChanged += new System.EventHandler(this.pizzaSizeCmboBx_SelectedIndexChanged);
            // 
            // pizzaSizeLbl
            // 
            this.pizzaSizeLbl.AutoSize = true;
            this.pizzaSizeLbl.Location = new System.Drawing.Point(30, 66);
            this.pizzaSizeLbl.Name = "pizzaSizeLbl";
            this.pizzaSizeLbl.Size = new System.Drawing.Size(55, 13);
            this.pizzaSizeLbl.TabIndex = 11;
            this.pizzaSizeLbl.Text = "Pizza Size";
            // 
            // mainTab
            // 
            this.mainTab.Controls.Add(this.tabPage1);
            this.mainTab.Controls.Add(this.tabPage2);
            this.mainTab.Controls.Add(this.tabPage3);
            this.mainTab.Controls.Add(this.tabPage4);
            this.mainTab.Location = new System.Drawing.Point(12, 12);
            this.mainTab.Name = "mainTab";
            this.mainTab.SelectedIndex = 0;
            this.mainTab.Size = new System.Drawing.Size(280, 391);
            this.mainTab.TabIndex = 14;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.companyLbl);
            this.tabPage1.Controls.Add(this.textName);
            this.tabPage1.Controls.Add(this.nameLbl);
            this.tabPage1.Controls.Add(this.addressLbl);
            this.tabPage1.Controls.Add(this.phoneLbl);
            this.tabPage1.Controls.Add(this.textPhone);
            this.tabPage1.Controls.Add(this.emailLbl);
            this.tabPage1.Controls.Add(this.textEmail);
            this.tabPage1.Controls.Add(this.textAddress);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(272, 365);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Customer Info";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(65, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(147, 129);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textPizzaQty);
            this.tabPage2.Controls.Add(this.pizzaQtyLbl);
            this.tabPage2.Controls.Add(this.toppingPriceLbl);
            this.tabPage2.Controls.Add(this.clearToppingBtn);
            this.tabPage2.Controls.Add(this.addToppingBtn);
            this.tabPage2.Controls.Add(this.toppingListAdd);
            this.tabPage2.Controls.Add(this.toppingList);
            this.tabPage2.Controls.Add(this.toppingInfoLbl);
            this.tabPage2.Controls.Add(this.pizzaSizeLbl);
            this.tabPage2.Controls.Add(this.sizeSelectedLbl);
            this.tabPage2.Controls.Add(this.pizzaSizeCmboBx);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(272, 365);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Toppings/Size";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textPizzaQty
            // 
            this.textPizzaQty.Location = new System.Drawing.Point(114, 102);
            this.textPizzaQty.Name = "textPizzaQty";
            this.textPizzaQty.Size = new System.Drawing.Size(100, 20);
            this.textPizzaQty.TabIndex = 22;
            // 
            // pizzaQtyLbl
            // 
            this.pizzaQtyLbl.AutoSize = true;
            this.pizzaQtyLbl.Location = new System.Drawing.Point(30, 105);
            this.pizzaQtyLbl.Name = "pizzaQtyLbl";
            this.pizzaQtyLbl.Size = new System.Drawing.Size(54, 13);
            this.pizzaQtyLbl.TabIndex = 21;
            this.pizzaQtyLbl.Text = "Pizza Qty:";
            // 
            // toppingPriceLbl
            // 
            this.toppingPriceLbl.AutoSize = true;
            this.toppingPriceLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toppingPriceLbl.Location = new System.Drawing.Point(158, 155);
            this.toppingPriceLbl.Name = "toppingPriceLbl";
            this.toppingPriceLbl.Size = new System.Drawing.Size(111, 135);
            this.toppingPriceLbl.TabIndex = 20;
            this.toppingPriceLbl.Text = "Small-$10\r\n\r\nMedium-$15\r\n\r\nLarge-$20\r\n\r\nToppings are $2\r\n\r\n\r\n";
            // 
            // clearToppingBtn
            // 
            this.clearToppingBtn.Location = new System.Drawing.Point(161, 327);
            this.clearToppingBtn.Name = "clearToppingBtn";
            this.clearToppingBtn.Size = new System.Drawing.Size(94, 23);
            this.clearToppingBtn.TabIndex = 19;
            this.clearToppingBtn.Text = "Clear Topping";
            this.clearToppingBtn.UseVisualStyleBackColor = true;
            this.clearToppingBtn.Click += new System.EventHandler(this.clearToppingBtn_Click);
            // 
            // addToppingBtn
            // 
            this.addToppingBtn.Location = new System.Drawing.Point(161, 298);
            this.addToppingBtn.Name = "addToppingBtn";
            this.addToppingBtn.Size = new System.Drawing.Size(94, 23);
            this.addToppingBtn.TabIndex = 18;
            this.addToppingBtn.Text = "Add Topping";
            this.addToppingBtn.UseVisualStyleBackColor = true;
            this.addToppingBtn.Click += new System.EventHandler(this.addToppingBtn_Click);
            // 
            // toppingListAdd
            // 
            this.toppingListAdd.FormattingEnabled = true;
            this.toppingListAdd.Location = new System.Drawing.Point(24, 255);
            this.toppingListAdd.Name = "toppingListAdd";
            this.toppingListAdd.Size = new System.Drawing.Size(120, 95);
            this.toppingListAdd.TabIndex = 17;
            // 
            // toppingList
            // 
            this.toppingList.FormattingEnabled = true;
            this.toppingList.Items.AddRange(new object[] {
            "Pepperoni",
            "Olives",
            "Chicken",
            "Green Pepper",
            "Mushrooms",
            "Sausage",
            "Bacon",
            "Banana Peppers",
            "Ground Beef",
            "Pineapple",
            "Extra Cheese",
            "Extra Sauce"});
            this.toppingList.Location = new System.Drawing.Point(24, 155);
            this.toppingList.Name = "toppingList";
            this.toppingList.Size = new System.Drawing.Size(120, 94);
            this.toppingList.TabIndex = 16;
            // 
            // toppingInfoLbl
            // 
            this.toppingInfoLbl.AutoSize = true;
            this.toppingInfoLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toppingInfoLbl.Location = new System.Drawing.Point(85, 20);
            this.toppingInfoLbl.Name = "toppingInfoLbl";
            this.toppingInfoLbl.Size = new System.Drawing.Size(75, 29);
            this.toppingInfoLbl.TabIndex = 14;
            this.toppingInfoLbl.Text = "Pizza";
            // 
            // sizeSelectedLbl
            // 
            this.sizeSelectedLbl.AutoSize = true;
            this.sizeSelectedLbl.Location = new System.Drawing.Point(111, 87);
            this.sizeSelectedLbl.Name = "sizeSelectedLbl";
            this.sizeSelectedLbl.Size = new System.Drawing.Size(0, 13);
            this.sizeSelectedLbl.TabIndex = 13;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pictureBox3);
            this.tabPage3.Controls.Add(this.drinkLbl);
            this.tabPage3.Controls.Add(this.bevInfoLbl);
            this.tabPage3.Controls.Add(this.bevQntyLbl);
            this.tabPage3.Controls.Add(this.textBevQty);
            this.tabPage3.Controls.Add(this.beverageSelectedLbl);
            this.tabPage3.Controls.Add(this.beverageLbl);
            this.tabPage3.Controls.Add(this.beverageCmboBx);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(272, 365);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Beverages";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(61, 166);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(149, 148);
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // drinkLbl
            // 
            this.drinkLbl.AutoSize = true;
            this.drinkLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drinkLbl.Location = new System.Drawing.Point(58, 330);
            this.drinkLbl.Name = "drinkLbl";
            this.drinkLbl.Size = new System.Drawing.Size(146, 17);
            this.drinkLbl.TabIndex = 20;
            this.drinkLbl.Text = "Drinks are $2 each";
            // 
            // bevInfoLbl
            // 
            this.bevInfoLbl.AutoSize = true;
            this.bevInfoLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bevInfoLbl.Location = new System.Drawing.Point(67, 18);
            this.bevInfoLbl.Name = "bevInfoLbl";
            this.bevInfoLbl.Size = new System.Drawing.Size(138, 29);
            this.bevInfoLbl.TabIndex = 19;
            this.bevInfoLbl.Text = "Beverages";
            // 
            // bevQntyLbl
            // 
            this.bevQntyLbl.AutoSize = true;
            this.bevQntyLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bevQntyLbl.Location = new System.Drawing.Point(42, 128);
            this.bevQntyLbl.Name = "bevQntyLbl";
            this.bevQntyLbl.Size = new System.Drawing.Size(38, 17);
            this.bevQntyLbl.TabIndex = 18;
            this.bevQntyLbl.Text = "Qty:";
            // 
            // textBevQty
            // 
            this.textBevQty.Location = new System.Drawing.Point(122, 128);
            this.textBevQty.Name = "textBevQty";
            this.textBevQty.Size = new System.Drawing.Size(72, 20);
            this.textBevQty.TabIndex = 17;
            // 
            // beverageSelectedLbl
            // 
            this.beverageSelectedLbl.AutoSize = true;
            this.beverageSelectedLbl.Location = new System.Drawing.Point(99, 102);
            this.beverageSelectedLbl.Name = "beverageSelectedLbl";
            this.beverageSelectedLbl.Size = new System.Drawing.Size(0, 13);
            this.beverageSelectedLbl.TabIndex = 16;
            // 
            // beverageLbl
            // 
            this.beverageLbl.AutoSize = true;
            this.beverageLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.beverageLbl.Location = new System.Drawing.Point(30, 70);
            this.beverageLbl.Name = "beverageLbl";
            this.beverageLbl.Size = new System.Drawing.Size(77, 17);
            this.beverageLbl.TabIndex = 14;
            this.beverageLbl.Text = "Beverage";
            // 
            // beverageCmboBx
            // 
            this.beverageCmboBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.beverageCmboBx.FormattingEnabled = true;
            this.beverageCmboBx.Items.AddRange(new object[] {
            "Cola",
            "Root Beer",
            "Lemon Soda",
            "Juice",
            "Water",
            "Sparkling Water"});
            this.beverageCmboBx.Location = new System.Drawing.Point(113, 70);
            this.beverageCmboBx.Name = "beverageCmboBx";
            this.beverageCmboBx.Size = new System.Drawing.Size(121, 21);
            this.beverageCmboBx.TabIndex = 15;
            this.beverageCmboBx.SelectedIndexChanged += new System.EventHandler(this.beverageCmboBx_SelectedIndexChanged);
            // 
            // resetBtn
            // 
            this.resetBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.resetBtn.Location = new System.Drawing.Point(184, 421);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(75, 23);
            this.resetBtn.TabIndex = 10;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            this.resetBtn.KeyDown += new System.Windows.Forms.KeyEventHandler(this.resetBtn_KeyDown);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.addVeggie);
            this.tabPage4.Controls.Add(this.pictureBox2);
            this.tabPage4.Controls.Add(this.addMeatLover);
            this.tabPage4.Controls.Add(this.addCheeseBread);
            this.tabPage4.Controls.Add(this.addBread);
            this.tabPage4.Controls.Add(this.addChicken);
            this.tabPage4.Controls.Add(this.extrasLbl);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(272, 365);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Extras";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // extrasLbl
            // 
            this.extrasLbl.AutoSize = true;
            this.extrasLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extrasLbl.Location = new System.Drawing.Point(77, 13);
            this.extrasLbl.Name = "extrasLbl";
            this.extrasLbl.Size = new System.Drawing.Size(97, 31);
            this.extrasLbl.TabIndex = 0;
            this.extrasLbl.Text = "Extras";
            // 
            // addChicken
            // 
            this.addChicken.AutoSize = true;
            this.addChicken.Location = new System.Drawing.Point(63, 139);
            this.addChicken.Name = "addChicken";
            this.addChicken.Size = new System.Drawing.Size(137, 17);
            this.addChicken.TabIndex = 1;
            this.addChicken.Text = "Add Chicken Strips - $5";
            this.addChicken.UseVisualStyleBackColor = true;
            // 
            // addBread
            // 
            this.addBread.AutoSize = true;
            this.addBread.Location = new System.Drawing.Point(63, 180);
            this.addBread.Name = "addBread";
            this.addBread.Size = new System.Drawing.Size(126, 17);
            this.addBread.TabIndex = 2;
            this.addBread.Text = "Add Bread Strips - $5";
            this.addBread.UseVisualStyleBackColor = true;
            // 
            // addCheeseBread
            // 
            this.addCheeseBread.AutoSize = true;
            this.addCheeseBread.Location = new System.Drawing.Point(63, 218);
            this.addCheeseBread.Name = "addCheeseBread";
            this.addCheeseBread.Size = new System.Drawing.Size(136, 17);
            this.addCheeseBread.TabIndex = 3;
            this.addCheeseBread.Text = "Add Cheese Bread - $6";
            this.addCheeseBread.UseVisualStyleBackColor = true;
            // 
            // addMeatLover
            // 
            this.addMeatLover.AutoSize = true;
            this.addMeatLover.Location = new System.Drawing.Point(63, 63);
            this.addMeatLover.Name = "addMeatLover";
            this.addMeatLover.Size = new System.Drawing.Size(112, 17);
            this.addMeatLover.TabIndex = 4;
            this.addMeatLover.Text = "Meat Lovers - $25";
            this.addMeatLover.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(63, 250);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(151, 94);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // addVeggie
            // 
            this.addVeggie.AutoSize = true;
            this.addVeggie.Location = new System.Drawing.Point(63, 101);
            this.addVeggie.Name = "addVeggie";
            this.addVeggie.Size = new System.Drawing.Size(121, 17);
            this.addVeggie.TabIndex = 6;
            this.addVeggie.Text = "Veggie Lovers - $25";
            this.addVeggie.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.resetBtn;
            this.ClientSize = new System.Drawing.Size(307, 458);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.mainTab);
            this.Controls.Add(this.orderBtn);
            this.Name = "Form1";
            this.Text = "Order";
            this.mainTab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label companyLbl;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label addressLbl;
        private System.Windows.Forms.Label phoneLbl;
        private System.Windows.Forms.Label emailLbl;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textAddress;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.TextBox textPhone;
        private System.Windows.Forms.Button orderBtn;
        private System.Windows.Forms.ComboBox pizzaSizeCmboBx;
        private System.Windows.Forms.Label pizzaSizeLbl;
        private System.Windows.Forms.TabControl mainTab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox beverageCmboBx;
        private System.Windows.Forms.Label beverageLbl;
        private System.Windows.Forms.Label sizeSelectedLbl;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label bevQntyLbl;
        private System.Windows.Forms.TextBox textBevQty;
        private System.Windows.Forms.Label beverageSelectedLbl;
        private System.Windows.Forms.Label toppingInfoLbl;
        private System.Windows.Forms.Label bevInfoLbl;
        private System.Windows.Forms.Label drinkLbl;
        private System.Windows.Forms.CheckedListBox toppingList;
        private System.Windows.Forms.ListBox toppingListAdd;
        private System.Windows.Forms.Button addToppingBtn;
        private System.Windows.Forms.Button clearToppingBtn;
        private System.Windows.Forms.Label toppingPriceLbl;
        private System.Windows.Forms.Label toppings;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox textPizzaQty;
        private System.Windows.Forms.Label pizzaQtyLbl;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label extrasLbl;
        private System.Windows.Forms.CheckBox addCheeseBread;
        private System.Windows.Forms.CheckBox addBread;
        private System.Windows.Forms.CheckBox addChicken;
        private System.Windows.Forms.CheckBox addVeggie;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.CheckBox addMeatLover;
    }
}

