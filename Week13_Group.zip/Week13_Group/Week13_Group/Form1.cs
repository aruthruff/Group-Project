﻿/* 
* Programmer: Anthony Ruthruff
*             Richard Carson
*             Kenneth Thompson
*             Nathaniel Gebers
*             
* Date: 05/02/2024
* Class: CITP 180
* Purpose:   Pizza Delivery App. User is initially prompted to enter contact information.
*            User is then able to choose pizza size/quantity, toppings, type of beverage/quantity
*            and extra items such as meat/veggie lovers pizza, chicken strips, and bread/cheese sticks.
*            Price of items are tallied until order is placed. Total cost will then be displayed
*            in separate window, along with contact info, pizza size, and type of beverage.
*            User can reset order at any time from order window or order summary window.
* Assignment: Chapter 10 - Programming Excercise 10
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week13_Group
{
    public partial class Form1 : Form
    {
        public static string name;
        public static string address;
        public static int phone;
        public static string email;
        public static string beverage;
        public static int bevQty;
        public static string pizzaSize;
        public static int pizzaCost;
        public static int pizzaQty;
        public static int toppingQty;
        public static int pizzaTotal;
        public static int totalCost;
        public static bool breadSticks;
        public static bool cheeseSticks;
        public static bool chickenStrips;
        public static bool veggieLover;
        public static bool meatLover;
        public static int extraCost;




        public Form1()
        {
            InitializeComponent();
        }

        private void pizzaSizeCmboBx_TextChanged(object sender, EventArgs e)
        {
            sizeSelectedLbl.Text = "You Selected: " + pizzaSizeCmboBx.Text;
            this.pizzaSizeCmboBx.SelectedIndexChanged += new System.EventHandler
                (this.pizzaSizeCmboBx_TextChanged);
        }

        private void pizzaSizeCmboBx_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (pizzaSizeCmboBx.SelectedIndex == null)
            {
            }

            else
            {
                pizzaSize = pizzaSizeCmboBx.SelectedItem.ToString();
            }
            if (pizzaSize == "Small")
            {
                pizzaCost = 10;
            }
            else if (pizzaSize == "Medium")
            {
                pizzaCost = 15;
            }
            else if (pizzaSize == "Large")
            {
                pizzaCost = 20;
            }

        }

        private void beverageCmboBx_SelectedIndexChanged(object sender, EventArgs e)
        {

            beverageSelectedLbl.Text = "You Selected: " + beverageCmboBx.Text;
            this.beverageCmboBx.SelectedIndexChanged += new System.EventHandler
               (this.beverageCmboBx_SelectedIndexChanged);
        }

        private void addToppingBtn_Click(object sender, EventArgs e)
        {

            foreach (string s in toppingList.CheckedItems)
                toppingListAdd.Items.Add(s);
        }
        private void clearToppingBtn_Click(object sender, EventArgs e)
        {
            toppingListAdd.Items.Clear();
        }

        private void ContactInfo()
        {
            name = textName.Text;
            address = textAddress.Text;
            phone = int.Parse(textPhone.Text);
            email = textEmail.Text;
        }

        private int Extras()
        {
            chickenStrips = addChicken.Checked;
            breadSticks = addBread.Checked;
            cheeseSticks = addCheeseBread.Checked;
            meatLover = addMeatLover.Checked;
            veggieLover = addVeggie.Checked;

            if (addCheeseBread.Checked)
            {
                extraCost += 6;
            }
            if (addBread.Checked)
            {
                extraCost += 5;
            }
            if (addChicken.Checked)
            {
                extraCost += 5;
            }
            if (addVeggie.Checked)
            {
                extraCost += 25;
            }
            if (addMeatLover.Checked)
            {
                extraCost += 25;
            }
            return extraCost;
        }

        private void Pizza()
        {
            pizzaSize = pizzaSizeCmboBx.Text;
            pizzaQty = int.Parse(textPizzaQty.Text);
            pizzaTotal = pizzaCost * pizzaQty;
            toppingQty *= 2;
        }

        public void Beverage()
        {
            beverage = beverageCmboBx.Text;
            bevQty = int.Parse(textBevQty.Text);
            bevQty *= 2;
        }
        public void Pricing()
        {
            Pizza();
            Beverage();
            Extras();

            totalCost = extraCost + pizzaTotal + bevQty + toppingQty;

        }



        private void orderBtn_Click(object sender, EventArgs e)
        {

            foreach (string x in toppingList.CheckedItems)
                toppingQty = toppingListAdd.Items.Count;

            if (string.IsNullOrEmpty(textName.Text + textAddress.Text + textEmail.Text + textPhone.Text))
            {
                MessageBox.Show("Please contact info");
            }

            else if (string.IsNullOrEmpty(textName.Text))
            {
                MessageBox.Show("Please enter name");
                textName.Text = " ";
            }
            else if (string.IsNullOrEmpty(textAddress.Text))
            {
                MessageBox.Show("Please enter address");
                textAddress.Text = " ";
            }
            else if (string.IsNullOrEmpty(textEmail.Text))
            {
                MessageBox.Show("Please enter email");
                textEmail.Text = " ";
            }
            else if (string.IsNullOrEmpty(textPhone.Text) || !int.TryParse(textPhone.Text, out phone))
            {
                MessageBox.Show("Please enter 7 digit phone number(no hyphens)");
                textPhone.Text = " ";
            }
            else if (string.IsNullOrEmpty(pizzaSizeCmboBx.Text))
            {

                MessageBox.Show("Please choose pizza size/toppings");
            }

            else if (string.IsNullOrEmpty(textEmail.Text))
            {
                MessageBox.Show("Please enter email");
                textEmail.Text = " ";
            }
            else if (string.IsNullOrEmpty(textBevQty.Text) || string.IsNullOrEmpty(beverageCmboBx.Text))
            {

                MessageBox.Show("Please choose a beverage and how many");
            }
            else
            {
                ContactInfo();
                Pricing();
                Checkout checkout = new Checkout();
                checkout.Show();
            }
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            textName.Text = " ";
            textAddress.Text = " ";
            textPhone.Text = " ";
            textEmail.Text = " ";
            textBevQty.Text = " ";
            beverageSelectedLbl.Text = " ";
            addChicken.Checked = false;
            addBread.Checked = false;
            addCheeseBread.Checked = false;
            addMeatLover.Checked = false;
            addVeggie.Checked = false;
            toppingListAdd.Items.Clear();
            extraCost = 0;
            for (int i = 0; i < toppingList.Items.Count; i++)
            { toppingList.SetItemChecked(i, false); }
        }

        private void resetBtn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                resetBtn.PerformClick();
            }
        }

        private void textName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                orderBtn.PerformClick();
            }
        }

        private void textAddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                orderBtn.PerformClick();
            }
        }

        private void textPhone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                orderBtn.PerformClick();
            }
        }

        private void textEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                orderBtn.PerformClick();
            }
        }
    }
}

























