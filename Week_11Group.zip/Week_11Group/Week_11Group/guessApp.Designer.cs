﻿namespace Week_11Group
{
    partial class guessApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guessBtn = new System.Windows.Forms.Button();
            this.inputTxt = new System.Windows.Forms.TextBox();
            this.inputLbl = new System.Windows.Forms.Label();
            this.resestBtn = new System.Windows.Forms.Button();
            this.guessTxt = new System.Windows.Forms.TextBox();
            this.guessLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // guessBtn
            // 
            this.guessBtn.Location = new System.Drawing.Point(41, 123);
            this.guessBtn.Name = "guessBtn";
            this.guessBtn.Size = new System.Drawing.Size(75, 23);
            this.guessBtn.TabIndex = 0;
            this.guessBtn.Text = "Guess";
            this.guessBtn.UseVisualStyleBackColor = true;
            this.guessBtn.Click += new System.EventHandler(this.button1_Click);
            this.guessBtn.KeyDown += new System.Windows.Forms.KeyEventHandler(this.button1_KeyDown);
            // 
            // inputTxt
            // 
            this.inputTxt.Location = new System.Drawing.Point(175, 23);
            this.inputTxt.Name = "inputTxt";
            this.inputTxt.Size = new System.Drawing.Size(100, 20);
            this.inputTxt.TabIndex = 1;
            this.inputTxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // inputLbl
            // 
            this.inputLbl.AutoSize = true;
            this.inputLbl.Location = new System.Drawing.Point(38, 23);
            this.inputLbl.Name = "inputLbl";
            this.inputLbl.Size = new System.Drawing.Size(119, 13);
            this.inputLbl.TabIndex = 2;
            this.inputLbl.Text = "Enter number for guess:";
            // 
            // resestBtn
            // 
            this.resestBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.resestBtn.Location = new System.Drawing.Point(200, 123);
            this.resestBtn.Name = "resestBtn";
            this.resestBtn.Size = new System.Drawing.Size(75, 23);
            this.resestBtn.TabIndex = 4;
            this.resestBtn.Text = "Reset";
            this.resestBtn.UseVisualStyleBackColor = true;
            this.resestBtn.Click += new System.EventHandler(this.button2_Click);
            this.resestBtn.KeyDown += new System.Windows.Forms.KeyEventHandler(this.button2_KeyDown);
            // 
            // guessTxt
            // 
            this.guessTxt.Location = new System.Drawing.Point(175, 74);
            this.guessTxt.Name = "guessTxt";
            this.guessTxt.Size = new System.Drawing.Size(100, 20);
            this.guessTxt.TabIndex = 5;
            // 
            // guessLbl
            // 
            this.guessLbl.AutoSize = true;
            this.guessLbl.Location = new System.Drawing.Point(38, 77);
            this.guessLbl.Name = "guessLbl";
            this.guessLbl.Size = new System.Drawing.Size(106, 13);
            this.guessLbl.TabIndex = 6;
            this.guessLbl.Text = "Total number of tries:";
            // 
            // Form1
            // 
            this.AcceptButton = this.guessBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.CancelButton = this.resestBtn;
            this.ClientSize = new System.Drawing.Size(329, 179);
            this.Controls.Add(this.guessLbl);
            this.Controls.Add(this.guessTxt);
            this.Controls.Add(this.resestBtn);
            this.Controls.Add(this.inputLbl);
            this.Controls.Add(this.inputTxt);
            this.Controls.Add(this.guessBtn);
            this.Name = "Form1";
            this.Text = "Number Guessing App";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button guessBtn;
        private System.Windows.Forms.TextBox inputTxt;
        private System.Windows.Forms.Label inputLbl;
        private System.Windows.Forms.Button resestBtn;
        private System.Windows.Forms.TextBox guessTxt;
        private System.Windows.Forms.Label guessLbl;
    }
}

