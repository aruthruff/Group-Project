﻿/*Programmer: Anthony Ruthruff
*             Richard Carson
*             Kenneth Thompson
*             Nathaniel Gebers
*             
* Date: 04 / 17 / 2024
* Class: CITP 180
* Purpose:   GUI guessing game app. Allows user to enter number until they guess correctly.
*            App keeps count of tries and displays number on each try.
*            Background will change colors depending on if user types high or low number.
*            Guess button is tied to enter key; Reset button to escape key, for easier usability.
*            Includes openening Message box with instructions, label that tells you when your "hot" or "cold"
*            and closing Message box showing user a goodbye message.
*
* Assignment: Chapter 9 - Programming Excercise 10
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_11Group
{
    public partial class guessApp : Form
    {
        public guessApp()
        {
            InitializeComponent();
            
            MessageBox.Show("Enter numbers 0-100. Window will change to green if correct." +
                "\n\nIf number is too low box will change to light blue." +
                "\n\nIf number is too high box will change to red.", "Instructions");
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ActiveControl = inputTxt;
            inputTxt.Focus();
        }

        private int randomNum;
        private int guessCount;

        private void Form1_Load(object sender, EventArgs e)
        {
            Random random = new Random();
            randomNum = random.Next(0, 100);
            guessCount = 0;
        }
            
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            MessageBox.Show("Have a great day!", "Program Closing....");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            guessCount += 1;
            int input;
            
            if (string.IsNullOrEmpty(inputTxt.Text) || !int.TryParse(inputTxt.Text, out input))
            {
                MessageBox.Show("Please enter a number");
                inputTxt.Text = " ";
            }
            else
            {

                if (input == randomNum)
                {
                    guessLbl.Text = "Correct!";
                    guessTxt.Text = $"You tried {guessCount} time(s)";
                    this.BackColor = Color.Green;
                    inputTxt.Text = " ";
                    guessLbl.Text = "Total number of tries:";
                }

                if (input > randomNum)
                {
                    guessLbl.Text = "Hot!";
                    guessTxt.Text = $"{guessCount} guess(es)";
                    this.BackColor = Color.Red;
                    inputTxt.Text = " ";
                }
                if (input < randomNum)
                {
                    guessLbl.Text = "Cold!";
                    guessTxt.Text = $"{guessCount} guess(es)";
                    this.BackColor = Color.LightBlue;
                    inputTxt.Text = " ";
                }
            }
        }
            
        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                inputTxt.Focus();
            }
        }

        private void button2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                resestBtn.PerformClick();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            randomNum = random.Next(0, 100);
            guessCount = 0;
            inputTxt.Text = " ";
            guessTxt.Text = " ";
            this.BackColor= SystemColors.Control;
        }
                
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                guessBtn.PerformClick();
            }
        }
    }
}
        


       
       


        

            



            

            
            
            










